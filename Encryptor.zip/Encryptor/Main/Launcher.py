import os
import sys
import subprocess
from argon2 import PasswordHasher
import hashlib
  
# ---------- CONFIGURATION ----------
ENCRYPTOR_DIR = "Encryptors"
PASSWORD_FILE = "master.hash"
REQUIRED_FILES = [
    "audiocrypt.py",
    "videocrypt.py",
    "imagecrypt.py",
    "filecrypt.py",
    "textcrypt.py"
]

ph = PasswordHasher()


# ---------- UTILITIES ----------
def ensure_password_file():
    if not os.path.isfile(PASSWORD_FILE):
        print("No password set. Creating new password…\n")
        pwd = input("Enter new password: ")

        # Generate full Argon2 hash
        full_hash = ph.hash(pwd)

        # Generate fixed-length 10,000 char derived hash
        resized = resize_hash(full_hash, 10000)

        with open(PASSWORD_FILE, "w") as f:
            f.write(full_hash + "\n")
            f.write(resized)

        print("\nPassword saved.\n")


def verify_project_structure():
    """Validate Encryptors directory and required script footprint."""

    print(">>> Ready for use\n")

    # Confirm the directory exists
    if not os.path.isdir(ENCRYPTOR_DIR):
        print(f"\n[ERROR] Required directory missing: {ENCRYPTOR_DIR}/")
        print("Action: Ensure the Encryptors folder is present in the project root.")
        sys.exit(1)

    # Identify missing files
    missing = [
        f for f in REQUIRED_FILES
        if not os.path.isfile(os.path.join(ENCRYPTOR_DIR, f))
    ]

    # Identify unexpected/extra files (optional governance)
    existing = set(os.listdir(ENCRYPTOR_DIR))
    required = set(REQUIRED_FILES)
    extras = sorted(existing - required)

    if missing:
        print("\n[ERROR] Missing required encryptor scripts:")
        for m in missing:
            print(f"   • {m}")
        print("\nAction: Restore the missing modules before launching.")
        sys.exit(1)

    # Not an error; informational only
    if extras:
        print("\n[INFO] Non-standard files detected in Encryptors/:")
        for e in extras:
            print(f"   • {e}")
        print("These files are ignored but remain accessible.")


def resize_hash(encoded_hash: str, target_len: int = 10000) -> str:
    import hashlib
    base = encoded_hash.encode()
    digest = hashlib.sha256(base).hexdigest()
    extended = encoded_hash + digest * 300  # ensures >10k chars
    return extended[:target_len]


def verify_password():
    with open(PASSWORD_FILE, "r") as f:
        full_hash = f.readline().strip()  # The REAL Argon2 hash
        # resized hash on line 2 is ignored

    while True:
        pwd = input("Password: ")

        try:
            ph.verify(full_hash, pwd)
            print("\nAccess granted.\n")
            return
        except Exception:
            print("\nIncorrect password.\n")


def print_menu():
    print("""
==============================
        ENCRYPTORS
==============================
1) Audio Encryptor
2) Video Encryptor
3) Image Encryptor
4) File Encryptor
5) Text Encryptor
Q) Quit
""")


def run_encryptor(choice):
    mapping = {
        "1": "audiocrypt.py",
        "2": "videocrypt.py",
        "3": "imagecrypt.py",
        "4": "filecrypt.py",
        "5": "textcrypt.py"
    }

    filename = mapping.get(choice)
    if not filename:
        print("Invalid choice.")
        return

    script_path = os.path.join(ENCRYPTOR_DIR, filename)

    print(f"Launching {filename}…\n")
    subprocess.run([sys.executable, script_path])


# ---------- MAIN ----------

def main():

    verify_project_structure()
    ensure_password_file()
    verify_password()

    while True:
        print_menu()
        choice = input("Select option: ").strip().upper()

        if choice == "Q":
            print("Goodbye.")
            break

        run_encryptor(choice)


if __name__ == "__main__":
    main()

