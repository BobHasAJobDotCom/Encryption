#!/usr/bin/env python3
"""
audio_encryptor.py

Encrypt / decrypt WAV audio using password-derived key + ChaCha20-Poly1305 AEAD.

File format (binary .aenc):
  MAGIC(4) = b'AENC'
  VERSION(1)
  SALT(16)
  NONCE(12)
  nchannels (H, 2 bytes)
  sampwidth  (H, 2 bytes)
  framerate  (I, 4 bytes)
  nframes    (I, 4 bytes)
  len_fname  (H, 2 bytes)
  filename bytes (utf-8)
  ciphertext bytes (ChaCha20-Poly1305 output, tag included)

Usage:
  Encrypt:
    python3 audio_encryptor.py -m E -i input.wav -o out.aenc
  Decrypt:
    python3 audio_encryptor.py -m D -i out.aenc -o recovered.wav
"""

import os
import struct
import json
import base64
import argparse
import getpass
from typing import Tuple

import wave

from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

# optional Argon2
try:
    from argon2.low_level import hash_secret_raw, Type as Argon2Type
    HAS_ARGON2 = True
except Exception:
    HAS_ARGON2 = False

# constants
MAGIC = b'AENC'
VERSION = 1
SALT_LEN = 16
NONCE_LEN = 12
KEY_LEN = 32
PBKDF2_ITERS = 200_000

ARGON2_TIME = 3
ARGON2_MEM_KB = 64 * 1024
ARGON2_PAR = 2
ARGON2_HASH_LEN = KEY_LEN

# struct formats
# after magic + version: SALT(16) + NONCE(12) + nch (H) + sampw (H) + fr (I) + nf (I) + fname_len(H)
HEADER_FIXED_FMT = f"!{SALT_LEN}s{NONCE_LEN}sHHIIH"  # big-endian

def derive_key(password: str, salt: bytes) -> bytes:
    if HAS_ARGON2:
        return hash_secret_raw(
            secret=password.encode('utf-8'),
            salt=salt,
            time_cost=ARGON2_TIME,
            memory_cost=ARGON2_MEM_KB,
            parallelism=ARGON2_PAR,
            hash_len=ARGON2_HASH_LEN,
            type=Argon2Type.ID
        )
    else:
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=KEY_LEN,
            salt=salt,
            iterations=PBKDF2_ITERS
        )
        return kdf.derive(password.encode('utf-8'))

def encrypt_wav_to_aenc(in_wav: str, out_aenc: str, password: str):
    # read WAV
    with wave.open(in_wav, 'rb') as w:
        nchannels = w.getnchannels()
        sampwidth = w.getsampwidth()
        framerate = w.getframerate()
        nframes = w.getnframes()
        params = w.getparams()
        frames = w.readframes(nframes)  # bytes of PCM

    # derive and encrypt
    salt = os.urandom(SALT_LEN)
    key = derive_key(password, salt)
    aead = ChaCha20Poly1305(key)
    nonce = os.urandom(NONCE_LEN)

    # AAD: include JSON metadata (params) so it's authenticated
    aad_obj = {
        "fmt": "wav",
        "nchannels": nchannels,
        "sampwidth": sampwidth,
        "framerate": framerate,
        "nframes": nframes,
    }
    aad = json.dumps(aad_obj, separators=(',',':')).encode('utf-8')

    ciphertext = aead.encrypt(nonce, frames, aad)

    # build header
    fname = os.path.basename(in_wav)
    fname_b = fname.encode('utf-8')
    header_fixed = struct.pack(HEADER_FIXED_FMT,
                               salt,
                               nonce,
                               nchannels,
                               sampwidth,
                               framerate,
                               nframes,
                               len(fname_b))
    with open(out_aenc, 'wb') as f:
        f.write(MAGIC)
        f.write(struct.pack("!B", VERSION))
        f.write(header_fixed)
        f.write(fname_b)
        f.write(ciphertext)

    print(f"Encrypted WAV -> {out_aenc} (frames={nframes}, {framerate}Hz, {nchannels}ch, {sampwidth*8}b)")

def decrypt_aenc_to_wav(in_aenc: str, out_wav: str, password: str):
    with open(in_aenc, 'rb') as f:
        magic = f.read(len(MAGIC))
        if magic != MAGIC:
            raise ValueError("Not a valid aenc file (bad magic).")
        ver_b = f.read(1)
        version = ver_b[0]
        fixed_sz = struct.calcsize(HEADER_FIXED_FMT)
        fixed = f.read(fixed_sz)
        if len(fixed) != fixed_sz:
            raise ValueError("File truncated (header).")
        salt, nonce, nchannels, sampwidth, framerate, nframes, fname_len = struct.unpack(HEADER_FIXED_FMT, fixed)
        fname_b = f.read(fname_len)
        if len(fname_b) != fname_len:
            raise ValueError("File truncated (filename).")
        fname = fname_b.decode('utf-8')
        ciphertext = f.read()
    # derive key
    key = derive_key(password, salt)
    aead = ChaCha20Poly1305(key)
    aad_obj = {
        "fmt": "wav",
        "nchannels": nchannels,
        "sampwidth": sampwidth,
        "framerate": framerate,
        "nframes": nframes,
    }
    aad = json.dumps(aad_obj, separators=(',',':')).encode('utf-8')
    try:
        plaintext_frames = aead.decrypt(nonce, ciphertext, aad)
    except Exception as e:
        raise ValueError("Decryption failed (wrong password or corrupted data).") from e

    # write WAV
    # if out_wav is directory, use original filename
    if os.path.isdir(out_wav):
        out_path = os.path.join(out_wav, fname)
    else:
        out_path = out_wav

    with wave.open(out_path, 'wb') as w:
        w.setnchannels(nchannels)
        w.setsampwidth(sampwidth)
        w.setframerate(framerate)
        w.writeframes(plaintext_frames)

    print(f"Decrypted -> {out_path} (frames={nframes}, {framerate}Hz, {nchannels}ch, {sampwidth*8}b)")

# CLI -----------------------------------------------------------------------

def interactive():
    print("Audio Encryptor (WAV ↔ .aenc) — ChaCha20-Poly1305 + Argon2/PBKDF2")
    print("Argon2 available:", "YES" if HAS_ARGON2 else "NO (PBKDF2 fallback)")
    mode = input("Encrypt (E) or Decrypt (D)? ").strip().upper()
    if mode not in ("E","D"):
        print("Choose E or D.")
        return
    inp = input("Input path: ").strip()
    outp = input("Output path: ").strip()
    pw = getpass.getpass("Password: ")
    if mode == "E":
        encrypt_wav_to_aenc(inp, outp, pw)
    else:
        decrypt_aenc_to_wav(inp, outp, pw)

def cli_args():
    p = argparse.ArgumentParser(description="Audio encryptor for WAV files (ChaCha20-Poly1305).")
    p.add_argument("-m","--mode", choices=["E","D"], help="E=encrypt, D=decrypt")
    p.add_argument("-i","--input", help="input file (wav for E, .aenc for D)")
    p.add_argument("-o","--output", help="output path or directory")
    p.add_argument("-p","--password", help="password (omit to be prompted)")
    args = p.parse_args()
    if not args.mode or not args.input or not args.output:
        interactive()
        return
    pw = args.password or getpass.getpass("Password: ")
    if args.mode == "E":
        encrypt_wav_to_aenc(args.input, args.output, pw)
    else:
        decrypt_aenc_to_wav(args.input, args.output, pw)

if __name__ == "__main__":
    cli_args()
