#!/usr/bin/env python3
"""
filecrypt.py

Password-based file encryptor/decryptor using:
 - Argon2id (if available) or PBKDF2-HMAC-SHA256 fallback
 - AES-256-GCM (authenticated encryption)
 - Streaming/chunked I/O so files of any size can be processed
 - Simple header format carrying salt, nonce, and original filename

Usage:
  Encrypt:
    python3 filecrypt.py -e path/to/input -o path/to/output
  Decrypt:
    python3 filecrypt.py -d path/to/encrypted -o path/to/output_dir

On encrypt the original filename is embedded and restored on decrypt (unless you choose output path override).
"""

import os
import sys
import argparse
import struct
import getpass

from typing import Tuple

# crypto
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

# optional Argon2
try:
    from argon2.low_level import hash_secret_raw, Type as Argon2Type
    HAS_ARGON2 = True
except Exception:
    HAS_ARGON2 = False

# Constants / format
MAGIC = b'FENC'            # 4 bytes
VERSION = 1                # 1 byte
SALT_LEN = 16              # bytes
NONCE_LEN = 12             # AES-GCM recommended 12 bytes
TAG_LEN = 16               # AES-GCM tag length
FNAME_LEN_FMT = "!H"       # 2 bytes unsigned short big-endian for filename length
FNAME_LEN_SZ = struct.calcsize(FNAME_LEN_FMT)

# PBKDF2 fallback params
PBKDF2_ITERS = 200_000
KEY_LEN = 32               # 256-bit AES key
CHUNK_SIZE = 64 * 1024     # 64 KiB streaming chunks

# Argon2 params (if available)
ARGON2_TIME = 3
ARGON2_MEM_KB = 64 * 1024  # 64 MiB
ARGON2_PAR = 2
ARGON2_HASH_LEN = KEY_LEN

# helpers --------------------------------------------------------------------

def derive_key(password: str, salt: bytes) -> bytes:
    """Derive a 32-byte key from password and salt.
    Uses Argon2id if available, otherwise PBKDF2-HMAC-SHA256 fallback."""
    if HAS_ARGON2:
        # Argon2id raw output
        return hash_secret_raw(
            secret=password.encode('utf-8'),
            salt=salt,
            time_cost=ARGON2_TIME,
            memory_cost=ARGON2_MEM_KB,
            parallelism=ARGON2_PAR,
            hash_len=ARGON2_HASH_LEN,
            type=Argon2Type.ID
        )
    else:
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=KEY_LEN,
            salt=salt,
            iterations=PBKDF2_ITERS,
            backend=default_backend()
        )
        return kdf.derive(password.encode('utf-8'))


def build_header(salt: bytes, nonce: bytes, orig_filename: str) -> bytes:
    """Construct header: MAGIC(4) | VERSION(1) | SALT | NONCE | FNAME_LEN(2) | FNAME(bytes)"""
    fname_bytes = orig_filename.encode('utf-8')
    if len(fname_bytes) > 65535:
        raise ValueError("Filename too long to embed.")
    parts = [
        MAGIC,
        struct.pack("!B", VERSION),
        salt,
        nonce,
        struct.pack(FNAME_LEN_FMT, len(fname_bytes)),
        fname_bytes
    ]
    return b"".join(parts)


def parse_header(f) -> Tuple[int, bytes, bytes, str]:
    """Read and parse header from open file object f at its current position.
    Returns (version, salt, nonce, original_filename)."""
    magic = f.read(len(MAGIC))
    if magic != MAGIC:
        raise ValueError("File is not a compatible encrypted file (bad magic).")
    ver_b = f.read(1)
    version = ver_b[0]
    salt = f.read(SALT_LEN)
    if len(salt) != SALT_LEN:
        raise ValueError("Truncated file (missing salt).")
    nonce = f.read(NONCE_LEN)
    if len(nonce) != NONCE_LEN:
        raise ValueError("Truncated file (missing nonce).")
    fname_len_data = f.read(FNAME_LEN_SZ)
    if len(fname_len_data) != FNAME_LEN_SZ:
        raise ValueError("Truncated file (missing filename length).")
    (fname_len,) = struct.unpack(FNAME_LEN_FMT, fname_len_data)
    fname_bytes = f.read(fname_len)
    if len(fname_bytes) != fname_len:
        raise ValueError("Truncated file (missing filename).")
    orig_filename = fname_bytes.decode('utf-8')
    return version, salt, nonce, orig_filename


# encrypt / decrypt ----------------------------------------------------------

def encrypt_file(in_path: str, out_path: str, password: str, embed_filename: bool = True):
    salt = os.urandom(SALT_LEN)
    key = derive_key(password, salt)
    nonce = os.urandom(NONCE_LEN)

    # original filename to embed
    orig_fname = os.path.basename(in_path) if embed_filename else ""

    header = build_header(salt, nonce, orig_fname)

    # AEAD with streaming using Cipher.encryptor() in GCM mode
    cipher = Cipher(algorithms.AES(key), modes.GCM(nonce), backend=default_backend())
    encryptor = cipher.encryptor()

    # Use filename as AAD to bind metadata
    aad = orig_fname.encode('utf-8')
    encryptor.authenticate_additional_data(aad)

    total_in = 0
    with open(in_path, 'rb') as fin, open(out_path, 'wb') as fout:
        fout.write(header)  # write header first
        while True:
            chunk = fin.read(CHUNK_SIZE)
            if not chunk:
                break
            total_in += len(chunk)
            ct = encryptor.update(chunk)
            if ct:
                fout.write(ct)
        # finalize and write tag
        try:
            final = encryptor.finalize()
        except Exception as e:
            raise RuntimeError("Encryption finalize failed: " + str(e))
        if final:
            fout.write(final)
        tag = encryptor.tag
        fout.write(tag)

    print(f"Encrypted '{in_path}' -> '{out_path}'. ({total_in} bytes encrypted).")


def decrypt_file(in_path: str, out_dir: str, password: str, out_override: str = None):
    total_size = os.path.getsize(in_path)
    with open(in_path, 'rb') as fin:
        # parse header
        version, salt, nonce, orig_fname = parse_header(fin)
        header_len = fin.tell()

        # ciphertext length = total_size - header_len - TAG_LEN
        if total_size < header_len + TAG_LEN:
            raise ValueError("File too short to contain ciphertext and tag.")
        ct_len = total_size - header_len - TAG_LEN

        # read ciphertext in streaming fashion by reading ct_len bytes
        # but we need tag value; read ciphertext and tag by seeking to the end for tag
        fin.seek(header_len + ct_len)
        tag = fin.read(TAG_LEN)
        if len(tag) != TAG_LEN:
            raise ValueError("Missing authentication tag.")
        # move back to just after header to stream ciphertext
        fin.seek(header_len)

        key = derive_key(password, salt)

        # build decryptor with tag provided
        cipher = Cipher(algorithms.AES(key), modes.GCM(nonce, tag), backend=default_backend())
        decryptor = cipher.decryptor()
        # set AAD same as encrypt
        decryptor.authenticate_additional_data(orig_fname.encode('utf-8'))

        # determine output path
        if out_override:
            out_path = out_override
        else:
            out_path = os.path.join(out_dir or ".", orig_fname or "decrypted_output")

        total_out = 0
        remaining = ct_len
        with open(out_path, 'wb') as fout:
            while remaining > 0:
                read_sz = CHUNK_SIZE if remaining >= CHUNK_SIZE else remaining
                chunk = fin.read(read_sz)
                if not chunk:
                    raise ValueError("Unexpected EOF while reading ciphertext.")
                remaining -= len(chunk)
                pt = decryptor.update(chunk)
                if pt:
                    fout.write(pt)
                    total_out += len(pt)
            # finalize (this will verify tag)
            try:
                final = decryptor.finalize()
            except Exception as e:
                # Integrity failure (wrong password or tampered data)
                # Remove partial output file
                try:
                    fout.close()
                    os.remove(out_path)
                except Exception:
                    pass
                raise ValueError("Decryption failed: authentication error (bad password or corrupted file).") from e
            if final:
                fout.write(final)
                total_out += len(final)

    print(f"Decrypted '{in_path}' -> '{out_path}'. ({total_out} bytes written).")


# CLI ------------------------------------------------------------------------

def parse_args():
    p = argparse.ArgumentParser(description="File encryptor / decryptor (password-based, AES-256-GCM).")
    grp = p.add_mutually_exclusive_group(required=True)
    grp.add_argument("-e", "--encrypt", metavar="IN", help="Encrypt input file")
    grp.add_argument("-d", "--decrypt", metavar="IN", help="Decrypt input file")
    p.add_argument("-o", "--output", metavar="OUT", help="Output file or output directory (decrypt).")
    p.add_argument("--no-fname", action="store_true", help="Don't embed original filename into the encrypted file.")
    return p.parse_args()

def main():
    args = parse_args()
    if args.encrypt:
        in_path = args.encrypt
        if not os.path.isfile(in_path):
            print("Input file not found.")
            return
        out_path = args.output or (in_path + ".enc")
        pw = getpass.getpass("Enter password: ")
        if not pw:
            print("Password cannot be empty.")
            return
        encrypt_file(in_path, out_path, pw, embed_filename=not args.no_fname)

    elif args.decrypt:
        in_path = args.decrypt
        if not os.path.isfile(in_path):
            print("Input file not found.")
            return
        pw = getpass.getpass("Enter password: ")
        if not pw:
            print("Password cannot be empty.")
            return
        # If user provided --output it may be file (explicit) or dir
        out_override = None
        out_dir = None
        if args.output:
            # if decrypt output ends with path separator or is an existing directory -> treat as directory
            if os.path.isdir(args.output) or args.output.endswith(os.path.sep):
                out_dir = args.output
            else:
                # treat as explicit file path to write decrypted content
                out_override = args.output
                # ensure containing dir exists
                os.makedirs(os.path.dirname(out_override) or ".", exist_ok=True)
        decrypt_file(in_path, out_dir, pw, out_override=out_override)

if __name__ == "__main__":
    main()


