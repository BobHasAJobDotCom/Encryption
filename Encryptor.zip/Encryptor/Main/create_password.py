from argon2 import PasswordHasher
import os
import hashlib

HASH_FILE = "master.hash"
FIXED_LEN = 10000  # always generate a 10,000-character derived hash


def resize_hash(encoded_hash: str, target_len: int = FIXED_LEN) -> str:
    """Generate a deterministic, extended hash string of fixed length."""

    base = encoded_hash.encode()
    digest = hashlib.sha256(base).hexdigest()

    # Multiply digest to ensure the string is > target_len
    extended = encoded_hash + (digest * 300)

    return extended[:target_len]


def main():
    print("=== Create Master Password ===")

    # Acquire password twice for validation
    pwd1 = input("Enter new master password: ")
    pwd2 = input("Confirm password: ")

    if pwd1 != pwd2:
        print("Error: Passwords do not match.")
        return

    ph = PasswordHasher()

    # Generate the real Argon2 hash
    full_hash = ph.hash(pwd1)

    # Generate the fixed-length 10k derived hash
    resized_hash = resize_hash(full_hash, FIXED_LEN)

    # Store both:
    # Line 1 = Argon2 authentic hash
    # Line 2 = 10,000-character resized hash
    with open(HASH_FILE, "w") as f:
        f.write(full_hash + "\n")
        f.write(resized_hash)

    print("\nMaster password created successfully.")
    print("Stored in:", os.path.abspath(HASH_FILE))
    print(f"Fixed hash length enforced: {FIXED_LEN} characters")


if __name__ == "__main__":
    main()

