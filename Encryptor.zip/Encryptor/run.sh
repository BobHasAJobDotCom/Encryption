#!/bin/bash

# Resolve absolute path of this script
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# Path to Main folder
PROJECT_DIR="$SCRIPT_DIR/Main"

# Move into Main
cd "$PROJECT_DIR" || { echo "Failed to enter Main directory."; exit 1; }

# Move into venv/bin
cd "venv/bin" || { echo "venv/bin not found."; exit 1; }

# Activate venv
echo "

"
source activate

# Move back to Main
cd ../.. || exit 1

# Run Launcher using venv's Python
echo "Loading launcher
"
./venv/bin/python3 Launcher.py

