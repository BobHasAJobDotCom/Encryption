#!/usr/bin/env python3
"""
crypto_tool_pbkdf2.py

Custom reversible encryptor with PBKDF2 key strengthening + salt.
Not a replacement for standardized authenticated encryption in production.
"""

import os
import base64
import hashlib
import getpass

# Config
SALT_LEN = 16            # bytes
PBKDF2_ITERS = 200_000   # iterations for PBKDF2-HMAC-SHA256
DK_LEN = 32              # derived key length in bytes
SHIFT_MOD = 7            # position-based small shift (same as before)


def derive_key(password: str, salt: bytes) -> bytes:
    """Derive a key from password and salt using PBKDF2-HMAC-SHA256."""
    return hashlib.pbkdf2_hmac(
        hash_name="sha256",
        password=password.encode("utf-8"),
        salt=salt,
        iterations=PBKDF2_ITERS,
        dklen=DK_LEN
    )


def encrypt(plaintext: str, password: str) -> str:
    """Encrypt plaintext with password. Returns Base64(salt + ciphertext)."""
    salt = os.urandom(SALT_LEN)
    key = derive_key(password, salt)
    pt_bytes = plaintext.encode("utf-8")

    out = bytearray()
    for i, b in enumerate(pt_bytes):
        k = key[i % len(key)]
        # XOR with derived key byte, then add position-based shift, wrap to 0-255
        enc_byte = ((b ^ k) + (i % SHIFT_MOD)) & 0xFF
        out.append(enc_byte)

    # Prepend salt so decryptor can re-derive the key
    bundle = salt + bytes(out)
    return base64.b64encode(bundle).decode("utf-8")


def decrypt(encoded_bundle: str, password: str) -> str:
    """Decrypt Base64(salt + ciphertext) with password. Returns plaintext string."""
    try:
        bundle = base64.b64decode(encoded_bundle)
    except Exception as e:
        raise ValueError("Input is not valid Base64.") from e

    if len(bundle) <= SALT_LEN:
        raise ValueError("Input too short or missing salt/ciphertext.")

    salt = bundle[:SALT_LEN]
    ct = bundle[SALT_LEN:]
    key = derive_key(password, salt)

    out = bytearray()
    for i, c in enumerate(ct):
        k = key[i % len(key)]
        # Reverse the position shift and XOR (use wrap arithmetic)
        dec_byte = (((c - (i % SHIFT_MOD)) & 0xFF) ^ k) & 0xFF
        out.append(dec_byte)

    try:
        return out.decode("utf-8")
    except UnicodeDecodeError as e:
        # Usually indicates wrong password or corrupted input
        raise ValueError("Decryption resulted in invalid UTF-8 (wrong key or corrupted data).") from e


def main():
    print("=== PBKDF2-hardened Custom Encryptor ===")
    mode = input("Encrypt (E) or Decrypt (D)? ").strip().upper()

    if mode == "E":
        text = input("Enter text to encrypt: ")
        pw = getpass.getpass("Enter password/key: ")
        if not pw:
            print("Password cannot be empty.")
            return
        result = encrypt(text, pw)
        print("\n[Encrypted - Base64(salt+ciphertext)]")
        print(result)
        print("\nNote: keep your password safe. Each encryption uses a fresh random salt.")

    elif mode == "D":
        cipher = input("Enter encrypted Base64 bundle: ").strip()
        pw = getpass.getpass("Enter password/key: ")
        if not pw:
            print("Password cannot be empty.")
            return
        try:
            plaintext = decrypt(cipher, pw)
            print("\n[Decrypted Plaintext]")
            print(plaintext)
        except ValueError as e:
            print("\nERROR:", str(e))

    else:
        print("Invalid option. Choose E or D.")


if __name__ == "__main__":
    main()
