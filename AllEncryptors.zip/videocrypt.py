#!/usr/bin/env python3
"""
video_scrambler.py

Encrypt / decrypt a video so it stays playable but visually scrambled.

- Mode E (encrypt): read input video, scramble each frame with AES-CTR keyed from password,
  keep audio intact, write scrambled video (playable) and a companion .meta JSON with salt+iv.
- Mode D (decrypt): read scrambled video + .meta + password, reverse per-frame scrambling,
  restore original video (including audio).

Notes:
- This is container/frame-level scrambling. It preserves audio by extracting and re-muxing
  using moviepy (ffmpeg under the hood).
- Uses Argon2id (if available) or PBKDF2 fallback for password -> key.
- Streaming frame-by-frame; no full-file memory footprint.
"""

import os
import sys
import json
import struct
import argparse
import getpass
import tempfile
from typing import Tuple

import numpy as np
import cv2
from moviepy.editor import VideoFileClip, AudioFileClip

from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

# Optional argon2
try:
    from argon2.low_level import hash_secret_raw, Type as Argon2Type
    HAS_ARGON2 = True
except Exception:
    HAS_ARGON2 = False

# Params
SALT_LEN = 16
BASE_IV_LEN = 16   # AES block size
KEY_LEN = 32       # AES-256
PBKDF2_ITERS = 200_000

ARGON2_TIME = 3
ARGON2_MEM_KB = 64 * 1024
ARGON2_PAR = 2
ARGON2_HASH_LEN = KEY_LEN

META_SUFFIX = ".meta.json"
TMP_AUDIO = ".__tmp_audio__.m4a"

# --- KDF -------------------------------------------------------------------

def derive_key(password: str, salt: bytes) -> bytes:
    if HAS_ARGON2:
        return hash_secret_raw(
            secret=password.encode('utf-8'),
            salt=salt,
            time_cost=ARGON2_TIME,
            memory_cost=ARGON2_MEM_KB,
            parallelism=ARGON2_PAR,
            hash_len=ARGON2_HASH_LEN,
            type=Argon2Type.ID
        )
    else:
        kdf = PBKDF2HMAC(algorithm=hashes.SHA256(), length=KEY_LEN, salt=salt, iterations=PBKDF2_ITERS)
        return kdf.derive(password.encode('utf-8'))

# --- IV derivation ---------------------------------------------------------
def derive_iv_for_frame(base_iv: bytes, frame_index: int) -> bytes:
    """Derive a unique 16-byte IV per frame from base_iv and frame_index.
    We add the frame_index to the last 8 bytes (big-endian) modulo 2^64.
    This produces a new IV for each frame while keeping changes local.
    """
    if len(base_iv) != BASE_IV_LEN:
        raise ValueError("base_iv length must be 16 bytes")
    hi = base_iv[:8]
    lo = base_iv[8:]
    lo_int = int.from_bytes(lo, 'big')
    new_lo = ((lo_int + frame_index) & ((1 << 64) - 1)).to_bytes(8, 'big')
    return hi + new_lo

# --- stream encrypt/decrypt helpers ---------------------------------------

def aes_ctr_xor_bytes(key: bytes, iv: bytes, data: bytes) -> bytes:
    """AES-CTR encrypt/decrypt (same operation) on raw bytes."""
    cipher = Cipher(algorithms.AES(key), modes.CTR(iv))
    op = cipher.encryptor()
    out = op.update(data) + op.finalize()
    return out

# --- main processing -------------------------------------------------------

def process_video_frames(in_path: str, out_path: str, key: bytes, base_iv: bytes, mode: str):
    """Read frames from in_path, encrypt/decrypt each frame, write to out_path (no audio).
    mode: 'E' for encrypt (scramble), 'D' for decrypt (unscramble). Operation is symmetric.
    """
    cap = cv2.VideoCapture(in_path)
    if not cap.isOpened():
        raise RuntimeError("Cannot open input video.")

    # Video properties
    fps = cap.get(cv2.CAP_PROP_FPS)
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fourcc = int(cap.get(cv2.CAP_PROP_FOURCC)) or cv2.VideoWriter_fourcc(*'mp4v')

    # ensure writer codec (mp4v fallback)
    out_fourcc = fourcc if fourcc != 0 else cv2.VideoWriter_fourcc(*'mp4v')

    writer = cv2.VideoWriter(out_path, out_fourcc, fps, (width, height))
    if not writer.isOpened():
        # try mp4v explicitly
        out_fourcc = cv2.VideoWriter_fourcc(*'mp4v')
        writer = cv2.VideoWriter(out_path, out_fourcc, fps, (width, height))
        if not writer.isOpened():
            raise RuntimeError("Cannot open output video writer. Check codecs and file extension.")

    frame_idx = 0
    read_count = 0
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        read_count += 1
        # frame is HxWx3 BGR uint8
        h, w, c = frame.shape
        # convert to contiguous bytes
        raw = frame.tobytes()

        iv = derive_iv_for_frame(base_iv, frame_idx)
        processed = aes_ctr_xor_bytes(key, iv, raw)

        # convert back to numpy array and reshape
        arr = np.frombuffer(processed, dtype=np.uint8)
        try:
            arr = arr.reshape((h, w, c))
        except Exception as e:
            cap.release()
            writer.release()
            raise RuntimeError("Frame reshape failed — internal error") from e

        # write frame (expects BGR)
        writer.write(arr)
        frame_idx += 1

    cap.release()
    writer.release()
    # return stats
    return {"frames": frame_idx, "fps": fps, "width": width, "height": height, "fourcc": out_fourcc}

# --- audio muxing ---------------------------------------------------------

def extract_audio(input_video: str, out_audio: str):
    """Extract audio using moviepy (ffmpeg)."""
    clip = VideoFileClip(input_video)
    if clip.audio is None:
        clip.close()
        return False
    clip.audio.write_audiofile(out_audio, verbose=False, logger=None)
    clip.close()
    return True

def mux_audio_video(video_path: str, audio_path: str, out_final: str):
    """Attach audio to video using moviepy (re-encodes container but keeps streams)."""
    clip = VideoFileClip(video_path)
    audioclip = AudioFileClip(audio_path) if os.path.exists(audio_path) else None
    if audioclip:
        clip = clip.set_audio(audioclip)
    clip.write_videofile(out_final, audio_codec='aac', verbose=False, logger=None)
    clip.close()
    if audioclip:
        audioclip.close()

# --- high-level encrypt/decrypt -------------------------------------------

def encrypt_video_playable(input_vid: str, output_vid: str, password: str):
    # build temp files
    tmp_video_noaudio = tempfile.NamedTemporaryFile(suffix=".mp4", delete=False).name
    tmp_audio = tempfile.NamedTemporaryFile(suffix=".m4a", delete=False).name

    salt = os.urandom(SALT_LEN)
    base_iv = os.urandom(BASE_IV_LEN)
    key = derive_key(password, salt)

    # extract audio (if any)
    has_audio = extract_audio(input_vid, tmp_audio)

    # scramble frames -> tmp_video_noaudio (without audio)
    stats = process_video_frames(input_vid, tmp_video_noaudio, key, base_iv, mode='E')

    # mux audio back into scrambled video
    if has_audio:
        mux_audio_video(tmp_video_noaudio, tmp_audio, output_vid)
    else:
        # if no audio, simply move tmp_video_noaudio to output_vid
        os.replace(tmp_video_noaudio, output_vid)

    # write metadata companion file
    meta = {
        "salt": salt.hex(),
        "base_iv": base_iv.hex(),
        "frames": stats["frames"],
        "fps": stats["fps"],
        "width": stats["width"],
        "height": stats["height"],
        "fourcc": stats["fourcc"],
        "has_audio": bool(has_audio)
    }
    meta_path = output_vid + META_SUFFIX
    with open(meta_path, 'w') as mf:
        json.dump(meta, mf)

    # cleanup temp audio and tmp_video_noaudio if still present
    try:
        if os.path.exists(tmp_audio):
            os.remove(tmp_audio)
        if os.path.exists(tmp_video_noaudio):
            # if we moved it to output_vid above, it won't exist; safe to ignore
            try:
                os.remove(tmp_video_noaudio)
            except Exception:
                pass
    except Exception:
        pass

    print(f"Encrypted & scrambled video saved to: {output_vid}")
    print(f"Metadata saved to: {meta_path}")
    print(f"Frames processed: {stats['frames']} — video remains playable but visually scrambled.")

def decrypt_video_playable(scrambled_vid: str, output_vid: str, password: str):
    meta_path = scrambled_vid + META_SUFFIX
    if not os.path.exists(meta_path):
        raise RuntimeError("Missing companion .meta.json file required for decryption.")
    with open(meta_path, 'r') as mf:
        meta = json.load(mf)
    salt = bytes.fromhex(meta["salt"])
    base_iv = bytes.fromhex(meta["base_iv"])
    key = derive_key(password, salt)

    # we need to extract audio to mux later (scrambled video already has audio preserved)
    tmp_video_noaudio = tempfile.NamedTemporaryFile(suffix=".mp4", delete=False).name
    tmp_audio = tempfile.NamedTemporaryFile(suffix=".m4a", delete=False).name

    # extract audio from scrambled (it contains original audio)
    has_audio = extract_audio(scrambled_vid, tmp_audio)

    # process frames: decrypt scrambled_vid -> tmp_video_noaudio
    stats = process_video_frames(scrambled_vid, tmp_video_noaudio, key, base_iv, mode='D')

    # mux audio back (audio is present in tmp_audio)
    if has_audio:
        mux_audio_video(tmp_video_noaudio, tmp_audio, output_vid)
    else:
        os.replace(tmp_video_noaudio, output_vid)

    # cleanup
    try:
        if os.path.exists(tmp_audio):
            os.remove(tmp_audio)
        if os.path.exists(tmp_video_noaudio):
            try:
                os.remove(tmp_video_noaudio)
            except Exception:
                pass
    except Exception:
        pass

    print(f"Decrypted & restored video saved to: {output_vid}")

# --- CLI -------------------------------------------------------------------

def main():
    p = argparse.ArgumentParser(description="Playable-but-scrambled video encryptor/decryptor.")
    p.add_argument("-m", "--mode", choices=["E","D"], required=True, help="E=encrypt(scramble), D=decrypt(unscramble)")
    p.add_argument("-i", "--input", required=True, help="Input video path")
    p.add_argument("-o", "--output", required=True, help="Output video path")
    p.add_argument("-p", "--password", help="Password (omit to be prompted)")
    args = p.parse_args()

    pw = args.password or getpass.getpass("Password: ")
    if not pw:
        print("Password cannot be empty.")
        sys.exit(1)

    if args.mode == "E":
        encrypt_video_playable(args.input, args.output, pw)
    else:
        decrypt_video_playable(args.input, args.output, pw)

if __name__ == "__main__":
    main()
