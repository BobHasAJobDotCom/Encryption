#!/usr/bin/env python3
"""
image_encryptor.py

Encrypt/decrypt PNG images in-place-like: output is a scrambled PNG that contains
the KDF salt + IV in PNG text chunks. Decryption restores the original image.

Usage (interactive):
  python3 image_encryptor.py

Usage (CLI):
  python3 image_encryptor.py -m E -i input.png -o out_encrypted.png
  python3 image_encryptor.py -m D -i out_encrypted.png -o recovered.png
"""

import os
import sys
import argparse
import base64
import getpass
from io import BytesIO

from PIL import Image, PngImagePlugin
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

# Optional Argon2
try:
    from argon2.low_level import hash_secret_raw, Type as Argon2Type
    HAS_ARGON2 = True
except Exception:
    HAS_ARGON2 = False

# Params
SALT_LEN = 16
IV_LEN = 16            # AES-CTR 16-byte IV
KEY_LEN = 32           # AES-256
PBKDF2_ITERS = 200_000

ARGON2_TIME = 3
ARGON2_MEM_KB = 64 * 1024
ARGON2_PAR = 2
ARGON2_HASH_LEN = KEY_LEN

PNG_META_SALT = "enc_salt"
PNG_META_IV = "enc_iv"
PNG_META_MODE = "orig_mode"

def derive_key(password: str, salt: bytes) -> bytes:
    if HAS_ARGON2:
        return hash_secret_raw(
            secret=password.encode('utf-8'),
            salt=salt,
            time_cost=ARGON2_TIME,
            memory_cost=ARGON2_MEM_KB,
            parallelism=ARGON2_PAR,
            hash_len=ARGON2_HASH_LEN,
            type=Argon2Type.ID
        )
    else:
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=KEY_LEN,
            salt=salt,
            iterations=PBKDF2_ITERS
        )
        return kdf.derive(password.encode('utf-8'))

def encrypt_image_png(input_path: str, output_path: str, password: str):
    # open and convert to RGBA for consistent structure
    img = Image.open(input_path)
    orig_mode = img.mode
    rgba = img.convert("RGBA")
    width, height = rgba.size
    pixel_bytes = rgba.tobytes()

    salt = os.urandom(SALT_LEN)
    iv = os.urandom(IV_LEN)
    key = derive_key(password, salt)

    # AES-CTR stream
    cipher = Cipher(algorithms.AES(key), modes.CTR(iv))
    encryptor = cipher.encryptor()
    encrypted_bytes = encryptor.update(pixel_bytes) + encryptor.finalize()

    # build image from encrypted bytes
    enc_img = Image.frombytes("RGBA", (width, height), encrypted_bytes)

    # add PNG metadata containing salt and iv (base64-encoded), and original mode
    pnginfo = PngImagePlugin.PngInfo()
    pnginfo.add_text(PNG_META_SALT, base64.b64encode(salt).decode('ascii'))
    pnginfo.add_text(PNG_META_IV, base64.b64encode(iv).decode('ascii'))
    pnginfo.add_text(PNG_META_MODE, orig_mode)

    enc_img.save(output_path, "PNG", pnginfo=pnginfo)
    print(f"Encrypted image saved to: {output_path} (original mode: {orig_mode})")

def decrypt_image_png(input_path: str, output_path: str, password: str):
    img = Image.open(input_path)
    info = img.info  # PNG text metadata

    if PNG_META_SALT not in info or PNG_META_IV not in info:
        raise ValueError("This PNG does not contain encryption metadata (not an encrypted PNG from this tool).")

    salt_b64 = info[PNG_META_SALT]
    iv_b64 = info[PNG_META_IV]
    orig_mode = info.get(PNG_META_MODE, "RGBA")

    salt = base64.b64decode(salt_b64)
    iv = base64.b64decode(iv_b64)
    key = derive_key(password, salt)

    # ensure we load pixel raw bytes as RGBA (the encrypted image was stored as RGBA)
    rgba = img.convert("RGBA")
    width, height = rgba.size
    enc_bytes = rgba.tobytes()

    cipher = Cipher(algorithms.AES(key), modes.CTR(iv))
    decryptor = cipher.decryptor()
    try:
        dec_bytes = decryptor.update(enc_bytes) + decryptor.finalize()
    except Exception as e:
        # stream ciphers won't detect wrong key reliably here, but result will be garbage or invalid image conversion
        raise ValueError("Decryption failed (likely wrong password).") from e

    # build image from decrypted bytes
    dec_img = Image.frombytes("RGBA", (width, height), dec_bytes)

    # convert back to original mode if possible
    try:
        out_img = dec_img.convert(orig_mode)
    except Exception:
        out_img = dec_img  # fallback to RGBA

    out_img.save(output_path)
    print(f"Decrypted image saved to: {output_path} (restored mode: {orig_mode})")

# CLI / interactive ----------------------------------------------------------

def interactive():
    print("Image Encryptor — PNG pixel-mode (RGBA XOR via AES-CTR)")
    choice = input("Encrypt (E) or Decrypt (D)? ").strip().upper()
    if choice not in ("E","D"):
        print("Choose E or D.")
        return
    inp = input("Input PNG path: ").strip()
    outp = input("Output path (PNG): ").strip()
    pw = getpass.getpass("Password: ")
    if choice == "E":
        encrypt_image_png(inp, outp, pw)
    else:
        decrypt_image_png(inp, outp, pw)

def cli_args():
    p = argparse.ArgumentParser(description="PNG Image encryptor (pixel-mode).")
    p.add_argument("-m","--mode", choices=["E","D"], help="E=encrypt, D=decrypt")
    p.add_argument("-i","--input", help="input PNG path")
    p.add_argument("-o","--output", help="output PNG path")
    p.add_argument("-p","--password", help="password (if omitted you will be prompted)")
    args = p.parse_args()
    if not args.mode or not args.input or not args.output:
        interactive()
        return
    pw = args.password or getpass.getpass("Password: ")
    if args.mode == "E":
        encrypt_image_png(args.input, args.output, pw)
    else:
        decrypt_image_png(args.input, args.output, pw)

if __name__ == "__main__":
    cli_args()
